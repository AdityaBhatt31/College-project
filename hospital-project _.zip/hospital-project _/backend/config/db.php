<?php
$conn = new mysqli("localhost","root","","hospital");
if($conn->connect_error){
    die("DB Failed");
}
?>