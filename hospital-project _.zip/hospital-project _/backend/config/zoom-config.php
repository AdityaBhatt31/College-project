<?php
// Zoom Configuration
define('ZOOM_CLIENT_ID', 't8jAl6mrQ9uBA4EGqEe30Q');
define('ZOOM_CLIENT_SECRET', 'nlf5eOxO50syD6Vl1mUNltDEQxivG6u8');
define('ZOOM_ACCOUNT_ID', 'nSjo8XOvQDqepFoJuC0rJA');

function getZoomToken() {
    $url = "https://zoom.us/oauth/token";
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($ch, CURLOPT_USERPWD, ZOOM_CLIENT_ID . ":" . ZOOM_CLIENT_SECRET);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=account_credentials&account_id=' . ZOOM_ACCOUNT_ID);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code != 200) {
        error_log("Zoom auth failed: " . $response);
        return null;
    }
    
    $data = json_decode($response, true);
    return $data['access_token'] ?? null;
}

function createZoomMeeting($doctorId, $patientName, $appointmentDate) {
    $token = getZoomToken();
    
    if (!$token) {
        error_log("Failed to get Zoom token");
        return null;
    }
    
    $meeting_data = [
        "topic" => "Doctor Appointment - " . $patientName,
        "type" => 1,  // Instant meeting
        "start_time" => date('Y-m-d\TH:i:s', strtotime($appointmentDate)),
        "duration" => 30,
        "timezone" => "Asia/Kolkata",
        "settings" => [
            "host_video" => true,
            "participant_video" => true,
            "approval_type" => 0,
            "auto_recording" => "none"
        ]
    ];
    
    $ch = curl_init("https://api.zoom.us/v2/users/me/meetings");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer " . $token,
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($meeting_data));
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code != 201) {
        error_log("Zoom meeting creation failed: " . $response);
        return null;
    }
    
    $meeting = json_decode($response, true);
    return $meeting['join_url'] ?? null;
}
?>