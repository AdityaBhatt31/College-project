<?php
// File: backend/setup-database.php
// Purpose: Add missing meeting_link column to appointments table
// Access: Open this file in browser: http://localhost/hospital-project/backend/setup-database.php

require_once "config/db.php";

echo "<!DOCTYPE html>";
echo "<html>";
echo "<head>";
echo "<title>Hospital DB Setup</title>";
echo "<style>";
echo "body { font-family: Arial; background: #f5f5f5; padding: 20px; }";
echo ".container { max-width: 600px; margin: auto; background: white; padding: 20px; border-radius: 8px; }";
echo ".success { color: green; padding: 10px; background: #e8f5e9; border-left: 4px solid green; margin: 10px 0; }";
echo ".error { color: red; padding: 10px; background: #ffebee; border-left: 4px solid red; margin: 10px 0; }";
echo ".info { color: #1976d2; padding: 10px; background: #e3f2fd; border-left: 4px solid #1976d2; margin: 10px 0; }";
echo "h1 { color: #333; }";
echo "pre { background: #f5f5f5; padding: 10px; border-radius: 4px; overflow-x: auto; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";
echo "<h1>🏥 Hospital Database Setup</h1>";

// Check if appointments table exists
$result = $conn->query("DESCRIBE appointments");
if (!$result) {
    echo "<div class='error'><strong>ERROR:</strong> appointments table not found!</div>";
    echo "<p>Please create the table first and try again.</p>";
} else {
    echo "<div class='info'><strong>✓ Found:</strong> appointments table exists</div>";
    
    // Get all columns
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    
    echo "<h3>Current Columns:</h3>";
    echo "<pre>";
    foreach ($columns as $col) {
        echo "• " . $col . "\n";
    }
    echo "</pre>";
    
    // Check if meeting_link column exists
    if (in_array('meeting_link', $columns)) {
        echo "<div class='success'><strong>✓ SUCCESS:</strong> meeting_link column already exists!</div>";
    } else {
        echo "<div class='error'><strong>⚠ MISSING:</strong> meeting_link column not found</div>";
        echo "<h3>Adding meeting_link column...</h3>";
        
        $sql = "ALTER TABLE appointments ADD COLUMN meeting_link VARCHAR(500) NULL";
        if ($conn->query($sql)) {
            echo "<div class='success'><strong>✓ SUCCESS:</strong> meeting_link column added!</div>";
            echo "<pre>Type: VARCHAR(500)\nDefault: NULL</pre>";
        } else {
            echo "<div class='error'><strong>ERROR:</strong> " . $conn->error . "</div>";
        }
    }
    
    // Show sample data
    echo "<h3>Sample Appointments:</h3>";
    $result = $conn->query("SELECT id, status, meeting_link FROM appointments LIMIT 5");
    if ($result && $result->num_rows > 0) {
        echo "<table border='1' cellpadding='10' style='width:100%; border-collapse:collapse;'>";
        echo "<tr style='background:#f5f5f5;'><th>ID</th><th>Status</th><th>Meeting Link</th></tr>";
        while ($row = $result->fetch_assoc()) {
            $link = $row['meeting_link'] ? $row['meeting_link'] : "NULL";
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['status'] . "</td>";
            echo "<td><code>" . htmlspecialchars($link) . "</code></td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div class='info'>No appointments found in database</div>";
    }
}

echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>Check that all columns are present ✓</li>";
echo "<li>Go to Doctor Dashboard</li>";
echo "<li>Approve an appointment</li>";
echo "<li>Check: 'Join Meeting' button should appear</li>";
echo "<li>Click to test Zoom link</li>";
echo "</ol>";

echo "</div>";
echo "</body>";
echo "</html>";

$conn->close();
?>
