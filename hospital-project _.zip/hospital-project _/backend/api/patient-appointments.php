<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Handle OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    include "../config/db.php";
    session_start();

    if(!isset($_SESSION["role"]) || $_SESSION["role"] !== "patient"){
        http_response_code(403);
        echo json_encode(["error" => "Access Denied"]);
        exit();
    }

    $patient_id = $_SESSION["id"];

    $stmt = $conn->prepare("SELECT a.id, a.date, a.time, a.status, a.meeting_link, d.id as doctor_id, d.name as doctor_name, d.specialization FROM appointments a JOIN doctors d ON a.doctor_id = d.id WHERE a.patient_id = ? ORDER BY a.date DESC");

    if(!$stmt){
        http_response_code(500);
        echo json_encode(["error" => "Query failed: " . $conn->error]);
        exit;
    }

    $stmt->bind_param("i", $patient_id);
    
    if(!$stmt->execute()){
        http_response_code(500);
        echo json_encode(["error" => "Execute failed: " . $stmt->error]);
        exit;
    }

    $result = $stmt->get_result();

    $appointments = [];
    while($row = $result->fetch_assoc()){
        $appointments[] = $row;
    }

    echo json_encode($appointments);
    $stmt->close();
    $conn->close();

} catch(Exception $e) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $e->getMessage()]);
}
?>
