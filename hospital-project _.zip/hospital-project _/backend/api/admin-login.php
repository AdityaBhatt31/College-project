<?php
session_start();
include '../config/db.php';

$data = json_decode(file_get_contents("php://input"));

$stmt = $conn->prepare("SELECT * FROM admins WHERE username=?");
$stmt->bind_param("s", $data->username);
$stmt->execute();

$res = $stmt->get_result();
$row = $res->fetch_assoc();

if($row && password_verify($data->password, $row['password'])){
    $_SESSION['role'] = "admins";
    $_SESSION['id'] = $row['id'];

    echo json_encode(["status"=>"success"]);
}else{
    echo json_encode(["status"=>"error"]);
}
?>