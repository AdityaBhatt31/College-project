<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set("Asia/Kolkata");



$CLIENT_ID = "Your Client Id";

$CLIENT_SECRET = "Your Client Secret";

$ACCOUNT_ID = "Your Account Id";



function getZoomAccessToken()
{
    global $CLIENT_ID;
    global $CLIENT_SECRET;
    global $ACCOUNT_ID;

    $url =
        "https://zoom.us/oauth/token?grant_type=account_credentials&account_id="
        . $ACCOUNT_ID;

    $auth =
        base64_encode(
            $CLIENT_ID . ":" . $CLIENT_SECRET
        );

    $ch = curl_init();

    curl_setopt_array($ch, [

        CURLOPT_URL => $url,

        CURLOPT_RETURNTRANSFER => true,

        CURLOPT_POST => true,

        CURLOPT_HTTPHEADER => [

            "Authorization: Basic " . $auth

        ]

    ]);

    $response = curl_exec($ch);

    curl_close($ch);

    return json_decode($response, true);
}


function createZoomMeeting(
    $date,
    $time,
    $patientName
)
{
    $tokenData = getZoomAccessToken();

    if (
        !isset($tokenData['access_token'])
    ) {

        return [
            "error" => "Unable to get Zoom access token",
            "response" => $tokenData
        ];
    }

    $accessToken =
        $tokenData['access_token'];

    $start_time =
        date(
            "Y-m-d\TH:i:s",
            strtotime($date . " " . $time)
        );

    $meetingData = [

        "topic" =>
            "Doctor Appointment - " . $patientName,

        "type" => 2,

        "start_time" => $start_time,

        "timezone" => "Asia/Kolkata",

        "duration" => 30,

        "agenda" => "Online Doctor Consultation",

        "settings" => [

            "host_video" => true,

            "participant_video" => true,

            "join_before_host" => true,

            "waiting_room" => false,

            "mute_upon_entry" => true

        ]
    ];

    $payload =
        json_encode($meetingData);

    $ch = curl_init();

    curl_setopt_array($ch, [

        CURLOPT_URL =>
            "https://api.zoom.us/v2/users/me/meetings",

        CURLOPT_RETURNTRANSFER => true,

        CURLOPT_POST => true,

        CURLOPT_POSTFIELDS => $payload,

        CURLOPT_HTTPHEADER => [

            "Authorization: Bearer " . $accessToken,

            "Content-Type: application/json"

        ]

    ]);

    $response = curl_exec($ch);

    curl_close($ch);

    return json_decode($response, true);
}

?>