<?php
include '../config/db.php';

$data = json_decode(file_get_contents("php://input"));

$name = $data->name;
$email = $data->email;
$phone = $data->phone;
$age = $data->age;
$gender = $data->gender;
$password = password_hash($data->password, PASSWORD_DEFAULT);

// Check if email exists
$check = $conn->prepare("SELECT id FROM patients WHERE email=?");
$check->bind_param("s", $email);
$check->execute();
$res = $check->get_result();

if($res->num_rows > 0){
    echo json_encode(["error"=>"Email already registered"]);
    exit();
}

// Insert data
$stmt = $conn->prepare("INSERT INTO patients(name,email,phone,age,gender,password) VALUES(?,?,?,?,?,?)");
$stmt->bind_param("sssiss", $name, $email, $phone, $age, $gender, $password);

if($stmt->execute()){
    echo json_encode(["status"=>"success"]);
}else{
    echo json_encode(["error"=>"Registration failed"]);
}
?>