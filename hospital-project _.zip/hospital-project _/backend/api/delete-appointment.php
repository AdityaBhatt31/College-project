<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include '../config/db.php';
session_start();

// Check if user is authenticated
if(!isset($_SESSION['id']) || !isset($_SESSION['role'])){
    echo json_encode(["error" => "Not authenticated"]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

$appointment_id = $data->appointment_id;
$user_type = $data->user_type;

$user_id = $_SESSION['id'];
$role = $_SESSION['role'];

// Verify ownership
if($user_type === "patient"){
    // Patient can only delete their own appointments
    $check = $conn->prepare("SELECT patient_id FROM appointments WHERE id = ?");
    $check->bind_param("i", $appointment_id);
    $check->execute();
    $result = $check->get_result();
    
    if($result->num_rows === 0){
        echo json_encode(["error" => "Appointment not found"]);
        exit();
    }
    
    $row = $result->fetch_assoc();
    if($row['patient_id'] != $user_id){
        echo json_encode(["error" => "Unauthorized"]);
        exit();
    }
} 
else if($user_type === "doctor"){
    // Doctor can only delete their own appointments
    $check = $conn->prepare("SELECT doctor_id FROM appointments WHERE id = ?");
    $check->bind_param("i", $appointment_id);
    $check->execute();
    $result = $check->get_result();
    
    if($result->num_rows === 0){
        echo json_encode(["error" => "Appointment not found"]);
        exit();
    }
    
    $row = $result->fetch_assoc();
    if($row['doctor_id'] != $user_id){
        echo json_encode(["error" => "Unauthorized"]);
        exit();
    }
}
else {
    echo json_encode(["error" => "Invalid user type"]);
    exit();
}

// Delete the appointment
$stmt = $conn->prepare("DELETE FROM appointments WHERE id = ?");
$stmt->bind_param("i", $appointment_id);

if($stmt->execute()){
    echo json_encode(["status" => "success", "message" => "Appointment deleted successfully"]);
} else {
    echo json_encode(["error" => "Failed to delete appointment"]);
}

$stmt->close();
$conn->close();
?>
