<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include '../config/db.php';

session_start();

// Agar doctor logged in hai toh sirf uske appointments + Cancelled na ho
if(isset($_SESSION['role']) && $_SESSION['role'] == "doctor"){
    $doctor_id = $_SESSION['id'];
    
    $stmt = $conn->prepare("
        SELECT * FROM appointments 
        WHERE doctor_id = ? 
        AND status != 'Cancelled'
        ORDER BY date ASC, time ASC
    ");
    $stmt->bind_param("i", $doctor_id);
    $stmt->execute();
    $res = $stmt->get_result();
}
else {
    // Admin ya patient ke liye saare (purana behavior)
    $res = $conn->query("SELECT * FROM appointments");
}

$data = [];

while($row = $res->fetch_assoc()){
    $data[] = $row;
}

echo json_encode($data);
?>