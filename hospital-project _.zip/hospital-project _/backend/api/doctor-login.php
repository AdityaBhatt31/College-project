<?php
session_start();
include '../config/db.php';

$data = json_decode(file_get_contents("php://input"));

$res = $conn->query("SELECT * FROM doctors WHERE name='$data->name'");
$row = $res->fetch_assoc();

if($row && password_verify($data->password, $row['password'])){
    $_SESSION['role'] = "doctor";
    $_SESSION['id'] = $row['id'];

    echo json_encode(["status"=>"success"]);
}else{
    echo json_encode(["status"=>"error"]);
}
?>