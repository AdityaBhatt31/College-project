<?php
session_start();
include '../config/db.php';

// Admin check
if(!isset($_SESSION['role']) || $_SESSION['role'] != "admins"){
    echo json_encode(["error"=>"Access Denied"]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

$name = $data->name;
$spec = $data->specialization;
$qual = $data->qualification;
$exp = $data->experience;
$fee = $data->fee;
$days = $data->available_days;
$mode = $data->mode;
$contact = $data->contact;
$password = password_hash($data->password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("
INSERT INTO doctors 
(name, specialization, qualification, experience, fee, available_days, mode, contact, password)
VALUES (?,?,?,?,?,?,?,?,?)
");

$stmt->bind_param("sssiissss", $name, $spec, $qual, $exp, $fee, $days, $mode, $contact, $password);

if($stmt->execute()){
    echo json_encode(["status"=>"Doctor Added Successfully"]);
}else{
    echo json_encode(["error"=>"Failed"]);
}
?>