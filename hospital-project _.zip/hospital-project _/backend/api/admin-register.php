<?php
include '../config/db.php';

$data = json_decode(file_get_contents("php://input"));

$username = $data->username;
$password = password_hash($data->password, PASSWORD_DEFAULT);

// Check duplicate
$check = $conn->prepare("SELECT id FROM admins WHERE username=?");
$check->bind_param("s", $username);
$check->execute();
$res = $check->get_result();

if($res->num_rows > 0){
    echo json_encode(["error"=>"Username already exists"]);
    exit();
}

// Insert admin
$stmt = $conn->prepare("INSERT INTO admins(username,password) VALUES(?,?)");
$stmt->bind_param("ss", $username, $password);

if($stmt->execute()){
    echo json_encode(["status"=>"success"]);
}else{
    echo json_encode(["error"=>"Registration failed"]);
}
?>