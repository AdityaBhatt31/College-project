<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Handle OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

session_start();
include '../config/db.php';

try {
    // Only patient allowed
    if(!isset($_SESSION['role']) || $_SESSION['role'] != "patient"){
        http_response_code(403);
        echo json_encode(["error" => "Access Denied - Not authenticated as patient"]);
        exit();
    }

    $data = json_decode(file_get_contents("php://input"));

    // Validate input
    if(!isset($data->doctor_id) || !isset($data->date) || !isset($data->time)){
        http_response_code(400);
        echo json_encode(["error" => "Missing required fields"]);
        exit();
    }

    $patient_id = $_SESSION['id'];
    $doctor_id = intval($data->doctor_id);
    $date = $data->date;
    $time = $data->time;
    $status = "Pending";

    // First check if patient and doctor exist
    $check_patient = $conn->prepare("SELECT id FROM patients WHERE id = ?");
    $check_patient->bind_param("i", $patient_id);
    $check_patient->execute();
    if($check_patient->get_result()->num_rows === 0){
        http_response_code(400);
        echo json_encode(["error" => "Patient not found"]);
        exit();
    }

    $check_doctor = $conn->prepare("SELECT id FROM doctors WHERE id = ?");
    $check_doctor->bind_param("i", $doctor_id);
    $check_doctor->execute();
    if($check_doctor->get_result()->num_rows === 0){
        http_response_code(400);
        echo json_encode(["error" => "Doctor not found"]);
        exit();
    }

    // Insert appointment
    $stmt = $conn->prepare("INSERT INTO appointments(patient_id, doctor_id, date, time, status) VALUES(?, ?, ?, ?, ?)");
    
    if(!$stmt){
        http_response_code(500);
        echo json_encode(["error" => "Prepare failed: " . $conn->error]);
        exit();
    }

    $stmt->bind_param("iisss", $patient_id, $doctor_id, $date, $time, $status);

    if($stmt->execute()){
        echo json_encode([
            "status" => "success",
            "message" => "✓ Appointment Booked Successfully",
            "appointment_id" => $stmt->insert_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Booking Failed: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();

} catch(Exception $e) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $e->getMessage()]);
}
?>