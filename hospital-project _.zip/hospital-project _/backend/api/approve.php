<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "../config/db.php";
require_once "generate-zoom-token.php";

try {

    // ===============================
    // AUTH CHECK
    // ===============================

    if (
        !isset($_SESSION['role']) ||
        $_SESSION['role'] != "doctor"
    ) {

        echo json_encode([
            "success" => false,
            "error" => "Access Denied"
        ]);

        exit;
    }

    // ===============================
    // GET JSON DATA
    // ===============================

    $rawData = file_get_contents("php://input");

    $data = json_decode($rawData, true);

    if (
        !$data ||
        !isset($data['appointment_id']) ||
        !isset($data['status'])
    ) {

        echo json_encode([
            "success" => false,
            "error" => "Missing appointment_id or status"
        ]);

        exit;
    }

    $appointment_id = intval($data['appointment_id']);

    $status = trim($data['status']);

    $zoom_link = null;

    // ===============================
    // CREATE ZOOM MEETING
    // ===============================

    if (strtolower($status) === "approved") {

        // Appointment Details

        $stmt = $conn->prepare("
            SELECT patient_id, date, time
            FROM appointments
            WHERE id = ?
        ");

        $stmt->bind_param("i", $appointment_id);

        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows == 0) {

            echo json_encode([
                "success" => false,
                "error" => "Appointment not found"
            ]);

            exit;
        }

        $appointment = $result->fetch_assoc();

        // Patient Details

        $patient_stmt = $conn->prepare("
            SELECT name
            FROM patients
            WHERE id = ?
        ");

        $patient_stmt->bind_param(
            "i",
            $appointment['patient_id']
        );

        $patient_stmt->execute();

        $patient_result = $patient_stmt->get_result();

        if ($patient_result->num_rows == 0) {

            echo json_encode([
                "success" => false,
                "error" => "Patient not found"
            ]);

            exit;
        }

        $patient = $patient_result->fetch_assoc();

        // ===============================
        // CREATE REAL ZOOM MEETING
        // ===============================

        $meeting = createZoomMeeting(
            $appointment['date'],
            $appointment['time'],
            $patient['name']
        );

        if (
            isset($meeting['join_url'])
        ) {

            $zoom_link = $meeting['join_url'];

        } else {

            echo json_encode([
                "success" => false,
                "error" => "Zoom meeting creation failed",
                "zoom_response" => $meeting
            ]);

            exit;
        }
    }

    // ===============================
    // UPDATE DATABASE
    // ===============================

    $update = $conn->prepare("
        UPDATE appointments
        SET status = ?, meeting_link = ?
        WHERE id = ?
    ");

    $update->bind_param(
        "ssi",
        $status,
        $zoom_link,
        $appointment_id
    );

    if ($update->execute()) {

        echo json_encode([

            "success" => true,

            "message" => "Appointment updated successfully",

            "appointment_id" => $appointment_id,

            "status" => $status,

            "zoom_link" => $zoom_link

        ]);

    } else {

        echo json_encode([

            "success" => false,

            "error" => $update->error

        ]);
    }

} catch (Exception $e) {

    echo json_encode([

        "success" => false,

        "error" => $e->getMessage()

    ]);
}

?>