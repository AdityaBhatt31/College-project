<?php
session_start();
include '../config/db.php';

// Login required
if(!isset($_SESSION['role'])){
    echo json_encode(["error"=>"Unauthorized"]);
    exit();
}

$result = $conn->query("
SELECT id, name, specialization, qualification, experience, fee, available_days, mode, contact 
FROM doctors
");

$data = [];

while($row = $result->fetch_assoc()){
    $data[] = $row;
}

echo json_encode($data);
?>