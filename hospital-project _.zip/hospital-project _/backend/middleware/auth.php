<?php
session_start();

if(!isset($_SESSION['role'])){
    echo json_encode(["error"=>"Unauthorized"]);
    exit();
}
?>