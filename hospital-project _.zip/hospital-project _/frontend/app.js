const API = "https://guardlike-delineable-carlyn.ngrok-free.dev/hospital-project/backend/api/";

// ================= ZOOM CONFIGURATION =================
const ZOOM_CONFIG = {
    CLIENT_ID: "Your Client Id",
    // Generate meeting tokens on your backend for security
    getToken: async (meetingNumber) => {
        try {
            const response = await fetch(API + "generate-zoom-token.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ meeting_number: meetingNumber })
            });
            const data = await response.json();
            // Return access_token if available, or the whole token response
            return data.access_token || data.token || null;
        } catch (err) {
            console.error("Error getting Zoom token:", err);
            return null;
        }
    }
};

function addDoctor(){

    const doctorData = {
        name: document.getElementById("name").value,
        specialization: document.getElementById("specialization").value,
        qualification: document.getElementById("qualification").value,
        experience: document.getElementById("experience").value,
        fee: document.getElementById("fee").value,
        available_days: document.getElementById("days").value,
        mode: document.getElementById("mode").value,
        contact: document.getElementById("contact").value,
        password: document.getElementById("password").value
    };

    for(let key in doctorData){

        if(doctorData[key] === ""){
            alert("Please fill all fields");
            return;
        }
    }

    fetch(API + "add-doctor.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify(doctorData)
    })
    .then(res => res.json())
    .then(data => {

        if(data.status){

            alert(data.status);

            document.getElementById("name").value = "";
            document.getElementById("specialization").value = "";
            document.getElementById("qualification").value = "";
            document.getElementById("experience").value = "";
            document.getElementById("fee").value = "";
            document.getElementById("days").value = "";
            document.getElementById("mode").value = "Online";
            document.getElementById("contact").value = "";
            document.getElementById("password").value = "";

        }else{
            alert(data.error || "Failed");
        }

    })
    .catch(err => {
        console.error(err);
        alert("Connection Error");
    });

}

// ================= LOGIN FUNCTIONS =================

function adminLogin(){
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    if(!username || !password){
        showAlert("Please fill all fields", "error");
        return;
    }

    fetch(API + "admin-login.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === "success"){
            localStorage.setItem("role", "admin");
            localStorage.setItem("id", data.id);
            window.location = "admin-dashboard.html";
        } else {
            showAlert(data.error || "Login Failed", "error");
        }
    })
    .catch(err => {
        console.error("Error:", err);
        showAlert("Connection error", "error");
    });
}

function doctorLogin(){
    let name = document.getElementById("name").value;
    let password = document.getElementById("password").value;

    if(!name || !password){
        showAlert("Please fill all fields", "error");
        return;
    }

    fetch(API + "doctor-login.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, password })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === "success"){
            localStorage.setItem("role", "doctor");
            localStorage.setItem("id", data.id);
            localStorage.setItem("name", data.name);
            window.location = "doctor-dashboard.html";
        } else {
            showAlert(data.error || "Login Failed", "error");
        }
    })
    .catch(err => {
        console.error("Error:", err);
        showAlert("Connection error", "error");
    });
}

function patientLogin(){
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    if(!email || !password){
        showAlert("Please fill all fields", "error");
        return;
    }

    fetch(API + "patient-login.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === "success"){
            localStorage.setItem("role", "patient");
            localStorage.setItem("id", data.id);
            localStorage.setItem("name", data.name);
            window.location = "patient-dashboard.html";
        } else {
            showAlert(data.error || "Login Failed", "error");
        }
    })
    .catch(err => {
        console.error("Error:", err);
        showAlert("Connection error", "error");
    });
}

// ================= PATIENT FUNCTIONS =================

function loadDoctors(){
    fetch(API + "get-doctors.php")
    .then(res => res.json())
    .then(data => {
        let html = "";
        let options = "<option value=''>-- Select a Doctor --</option>";

        data.forEach(d => {
            html += `
                <div class="doctor-card">
                    <div class="doctor-header">
                        <h3>${d.name}</h3>
                        <span class="specialization-badge">${d.specialization}</span>
                    </div>
                    <div class="doctor-info">
                        <p><strong>Qualification:</strong> ${d.qualification || 'N/A'}</p>
                        <p><strong>Experience:</strong> ${d.experience || 'N/A'} years</p>
                        <p><strong>Fee:</strong> <span class="fee">₹${d.fee}</span></p>
                        <p><strong>Mode:</strong> ${d.mode}</p>
                        <p><strong>Available:</strong> ${d.available_days}</p>
                    </div>
                </div>
            `;
            options += `<option value="${d.id}">${d.name} - ${d.specialization}</option>`;
        });

        if(document.getElementById("doctors")){
            document.getElementById("doctors").innerHTML = html || "<p class='no-data'>No doctors available</p>";
        }
        if(document.getElementById("doctor_id")){
            document.getElementById("doctor_id").innerHTML = options;
        }
    })
    .catch(err => {
        console.error("Error loading doctors:", err);
        showAlert("Error loading doctors", "error");
    });
}

function book(){
    let doctor_id = document.getElementById("doctor_id").value;
    let date = document.getElementById("date").value;
    let time = document.getElementById("time").value;

    if(!doctor_id || !date || !time){
        showAlert("Please select doctor, date, and time", "error");
        return;
    }

    const selectedDate = new Date(date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if(selectedDate < today){
        showAlert("Please select a future date", "error");
        return;
    }

    fetch(API + "book.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ doctor_id: parseInt(doctor_id), date, time })
    })
    .then(res => {
        if(!res.ok) {
            return res.json().then(data => {
                throw new Error(data.error || `HTTP ${res.status}`);
            });
        }
        return res.json();
    })
    .then(data => {
        if(data.status === "success"){
            showAlert("✓ Appointment booked successfully!", "success");
            document.getElementById("doctor_id").value = "";
            document.getElementById("date").value = "";
            document.getElementById("time").value = "";
            setTimeout(() => loadPatientAppointments(), 500);
        } else {
            showAlert(data.error || data.message || "Booking failed", "error");
        }
    })
    .catch(err => {
        console.error("Booking Error:", err);
        showAlert("Error: " + err.message, "error");
    });
}

function loadPatientAppointments(){
    fetch(API + "patient-appointments.php", {
        credentials: "include"
    })
    .then(res => {
        if(!res.ok) {
            return res.json().then(data => {
                throw new Error(data.error || `HTTP ${res.status}`);
            });
        }
        return res.json();
    })
    .then(data => {
        // Check if data is an array or has error
        if(data.error){
            throw new Error(data.error);
        }

        let html = "";

        if(!Array.isArray(data) || data.length === 0){
            html = "<p class='no-data'>No appointments booked yet. Book one now!</p>";
        } else {
            data.forEach(a => {
                const statusColor = a.status === 'Approved' ? 'approved' : 
                                   a.status === 'Pending' ? 'pending' : 'cancelled';
                const statusIcon = a.status === 'Approved' ? '✓' : 
                                  a.status === 'Pending' ? '⏳' : '✕';
                
                html += `
                    <div class="appointment-card status-${statusColor}">
                        <div class="appointment-header">
                            <div class="doctor-info-mini">
                                <h4>${a.doctor_name}</h4>
                                <p class="spec">${a.specialization}</p>
                            </div>
                            <span class="status-badge status-${statusColor}">${statusIcon} ${a.status}</span>
                        </div>
                        <div class="appointment-details">
                            <div class="detail-item">
                                <span class="icon">📅</span>
                                <span>${formatDate(a.date)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="icon">🕐</span>
                                <span>${a.time}</span>
                            </div>
                        </div>
                        <div class="appointment-actions">
                            ${a.status === "Approved" && a.meeting_link ? `
                                <button class="btn btn-primary" onclick="joinZoomMeeting(this.dataset.link)" data-link="${a.meeting_link}">
                                    📹 Join Call
                                </button>
                            ` : ''}
                            <button class="btn btn-secondary" onclick="deleteAppointment(${a.id}, 'patient')">
                                🗑️ Delete
                            </button>
                        </div>
                    </div>
                `;
            });
        }

        document.getElementById("appointments").innerHTML = html;
    })
    .catch(err => {
        console.error("Error loading appointments:", err);
        document.getElementById("appointments").innerHTML = `<p class='error'>⚠️ Error: ${err.message}</p>`;
    });
}

// ================= DOCTOR FUNCTIONS =================

function loadAppointments(){
    fetch(API + "doctor-appointments.php", {
        credentials: "include"
    })
    .then(res => {
        if(!res.ok) {
            return res.json().then(data => {
                throw new Error(data.error || `HTTP ${res.status}`);
            });
        }
        return res.json();
    })
    .then(data => {
        // Check if data is an array or has error
        if(data.error){
            throw new Error(data.error);
        }

        let html = "";

        if(!Array.isArray(data) || data.length === 0){
            html = "<p class='no-data'>No appointments scheduled.</p>";
        } else {
            data.forEach(a => {
                const statusColor = a.status === 'Approved' ? 'approved' : 
                                   a.status === 'Pending' ? 'pending' : 'cancelled';
                const statusIcon = a.status === 'Approved' ? '✓' : 
                                  a.status === 'Pending' ? '⏳' : '✕';
                
                html += `
                    <div class="appointment-card status-${statusColor}">
                        <div class="appointment-header">
                            <div class="patient-info-mini">
                                <h4>${a.patient_name}</h4>
                                <p class="contact">${a.patient_email}</p>
                            </div>
                            <span class="status-badge status-${statusColor}">${statusIcon} ${a.status}</span>
                        </div>
                        <div class="appointment-details">
                            <div class="detail-item">
                                <span class="icon">📅</span>
                                <span>${formatDate(a.date)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="icon">🕐</span>
                                <span>${a.time}</span>
                            </div>
                            <div class="detail-item">
                                <span class="icon">📱</span>
                                <span>${a.patient_phone || 'N/A'}</span>
                            </div>
                        </div>
                        <div class="appointment-actions">
                            ${a.status === 'Pending' ? `
                                <button class="btn btn-success" onclick="updateAppointment(${a.id}, 'Approved')">
                                    ✓ Approve
                                </button>
                                <button class="btn btn-warning" onclick="updateAppointment(${a.id}, 'Cancelled')">
                                    ✕ Reject
                                </button>
                            ` : ''}
                            
                            ${a.status === 'Approved' && a.meeting_link ? `
                                <button class="btn btn-primary" onclick="joinZoomMeeting(this.dataset.link)" data-link="${a.meeting_link}">
                                    📹 Join Call
                                </button>
                            ` : ''}
                            
                            <button class="btn btn-secondary" onclick="deleteAppointment(${a.id}, 'doctor')">
                                🗑️ Delete
                            </button>
                        </div>
                    </div>
                `;
            });
        }

        document.getElementById("appointments").innerHTML = html;
    })
    .catch(err => {
        console.error("Error loading appointments:", err);
        document.getElementById("appointments").innerHTML = `<p class='error'>⚠️ Error: ${err.message}</p>`;
    });
}

function updateAppointment(id, status){
    fetch(API + "approve.php", {
        method: "POST",
        headers: { 
            "Content-Type": "application/json" 
        },
        credentials: "include",
        body: JSON.stringify({ 
            appointment_id: id, 
            status: status 
        })
    })
    .then(res => {
        if (!res.ok) {
            return res.json().then(data => {
                throw new Error(data.error || `HTTP ${res.status}`);
            });
        }
        return res.json();
    })
    .then(data => {
        if(data.status === "success"){
            let message = `✓ Appointment ${status}`;
            if(status === "Approved" || status === "approved"){
                if(data.has_meeting_link){
                    message += " - Zoom link generated ✨";
                } else {
                    message += " (Zoom link generation pending)";
                }
            }
            showAlert(message, "success");
            setTimeout(() => loadAppointments(), 500);
        } else {
            showAlert(data.error || "Error updating appointment", "error");
        }
    })
    .catch(err => {
        console.error("Appointment Update Error:", err.message);
        showAlert("Error: " + err.message, "error");
    });
}

function deleteAppointment(id, userType){
    if(!confirm("Are you sure you want to delete this appointment?\nThis action cannot be undone.")){
        return;
    }

    fetch(API + "delete-appointment.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ appointment_id: id, user_type: userType })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === "success"){
            showAlert("✓ Appointment deleted", "success");
            if(userType === "patient"){
                loadPatientAppointments();
            } else {
                loadAppointments();
            }
        } else {
            showAlert(data.error || "Error deleting appointment", "error");
        }
    })
    .catch(err => {
        console.error("Error:", err);
        showAlert("Connection error", "error");
    });
}

// ================= ZOOM INTEGRATION =================

async function joinZoomMeeting(meetingLink, meetingNumber){

    if(!meetingLink){

        showAlert("Meeting link not available", "error");
        return;
    }

    try{

        // Open Zoom Link directly - no token needed for web join
        const zoomWindow = window.open(
            meetingLink,
            "_blank",
            "width=1200,height=700"
        );

        if(!zoomWindow){

            showAlert(
                "Please allow popups to join the meeting",
                "error"
            );
        } else {
            console.log("Zoom meeting opened successfully");
        }

    }catch(err){

        console.error("Zoom Join Error:", err);

        showAlert("Error joining Zoom meeting", "error");
    }
}

// ================= REGISTRATION FUNCTIONS =================

function register(){
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let phone = document.getElementById("phone").value;
    let age = document.getElementById("age").value;
    let gender = document.getElementById("gender").value;
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword")?.value;

    if(!name || !email || !password){
        showAlert("Please fill all required fields", "error");
        return;
    }

    if(confirmPassword && password !== confirmPassword){
        showAlert("Passwords do not match", "error");
        return;
    }

    if(password.length < 6){
        showAlert("Password must be at least 6 characters", "error");
        return;
    }

    fetch(API + "patient-register.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, phone, age, gender, password })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === "success"){
            showAlert("✓ Registration successful! Redirecting to login...", "success");
            setTimeout(() => window.location = "patient-login.html", 2000);
        } else {
            showAlert(data.error || "Registration failed", "error");
        }
    })
    .catch(err => {
        console.error("Error:", err);
        showAlert("Connection error", "error");
    });
}

function adminRegister(){
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword")?.value;

    if(!username || !password){
        showAlert("Please fill all fields", "error");
        return;
    }

    if(confirmPassword && password !== confirmPassword){
        showAlert("Passwords do not match", "error");
        return;
    }

    fetch(API + "admin-register.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === "success"){
            showAlert("✓ Admin registered! Redirecting to login...", "success");
            setTimeout(() => window.location = "admin-login.html", 2000);
        } else {
            showAlert(data.error || "Registration failed", "error");
        }
    })
    .catch(err => {
        console.error("Error:", err);
        showAlert("Connection error", "error");
    });
}

// ================= UTILITY FUNCTIONS =================

function logout(){
    if(!confirm("Are you sure you want to logout?")){
        return;
    }
    
    fetch(API + "logout.php")
    .then(() => {
        localStorage.clear();
        window.location = "index.html";
    })
    .catch(err => {
        console.error("Error:", err);
        localStorage.clear();
        window.location = "index.html";
    });
}

function showAlert(message, type = "info"){
    const alertDiv = document.createElement("div");
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    const bgColor = type === 'success' ? '#d4edda' : 
                   type === 'error' ? '#f8d7da' : '#d1ecf1';
    const textColor = type === 'success' ? '#155724' : 
                     type === 'error' ? '#721c24' : '#0c5460';
    const borderColor = type === 'success' ? '#c3e6cb' : 
                       type === 'error' ? '#f5c6cb' : '#bee5eb';
    
    alertDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${bgColor};
        color: ${textColor};
        border-left: 4px solid ${textColor};
        border-radius: 4px;
        z-index: 10000;
        max-width: 400px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        font-weight: 500;
        animation: slideIn 0.3s ease-out;
    `;

    document.body.appendChild(alertDiv);

    setTimeout(() => {
        alertDiv.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => alertDiv.remove(), 300);
    }, 3500);
}

function formatDate(dateStr){
    const date = new Date(dateStr);
    const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
    return date.toLocaleDateString('en-US', options);
}

function checkAuth(requiredRole){
    const role = localStorage.getItem("role");
    if(!role || role !== requiredRole){
        window.location = requiredRole + "-login.html";
    }
}